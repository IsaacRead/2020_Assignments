open console:

python3 part1.py


Sample output:

[1, 0, 0, 1]
[1, 0, 1, 0]
[1, 1, 0, 1]
[1, 1, 1, 0]
[1, 1, 1, 1]
[1, 1, 0, 0]
[1, 0, 1, 1]
[1, 0, 0, 0]
3
[0.5, 0.5, 0.5, 0.5]
------
decrease weights
Epoch:  0
Accuracy:  0.5
------
correct
Epoch:  1
Accuracy:  0.5
------
correct
Epoch:  2
Accuracy:  0.5
------
decrease weights
Epoch:  3
Accuracy:  0.5
------
decrease weights
Epoch:  4
Accuracy:  0.5
------
correct
Epoch:  5
Accuracy:  0.5
------
correct
Epoch:  6
Accuracy:  0.5
------
decrease weights
Epoch:  7
Accuracy:  0.5
------
decrease weights
Epoch:  8
Accuracy:  0.5
------
correct
Epoch:  9
Accuracy:  0.5
------
correct
Epoch:  10
Accuracy:  0.5
------
decrease weights
Epoch:  11
Accuracy:  0.625
------
decrease weights
Epoch:  12
Accuracy:  0.5
------
increase weights
Epoch:  13
Accuracy:  0.625
------
correct
Epoch:  14
Accuracy:  0.625
------
correct
Epoch:  15
Accuracy:  0.625
------
decrease weights
Epoch:  16
Accuracy:  0.5
------
increase weights
Epoch:  17
Accuracy:  0.75
------
correct
Epoch:  18
Accuracy:  0.75
------
decrease weights
Epoch:  19
Accuracy:  0.25
------
decrease weights
Epoch:  20
Accuracy:  0.5
------
increase weights
Epoch:  21
Accuracy:  0.5
------
increase weights
Epoch:  22
Accuracy:  0.75
------
correct
Epoch:  23
Accuracy:  0.75
------
correct
Epoch:  24
Accuracy:  0.75
------
correct
Epoch:  25
Accuracy:  0.75
------
correct
Epoch:  26
Accuracy:  0.75
------
decrease weights
Epoch:  27
Accuracy:  0.5
------
correct
Epoch:  28
Accuracy:  0.5
------
increase weights
Epoch:  29
Accuracy:  0.5
------
increase weights
Epoch:  30
Accuracy:  0.5
------
decrease weights
Epoch:  31
Accuracy:  0.625
------
decrease weights
Epoch:  32
Accuracy:  0.25
------
increase weights
Epoch:  33
Accuracy:  0.75
------
correct
Epoch:  34
Accuracy:  0.75
------
decrease weights
Epoch:  35
Accuracy:  0.5
------
correct
Epoch:  36
Accuracy:  0.5
------
increase weights
Epoch:  37
Accuracy:  0.75
------
correct
Epoch:  38
Accuracy:  0.75
------
correct
Epoch:  39
Accuracy:  0.75
------
correct
Epoch:  40
Accuracy:  0.75
------
correct
Epoch:  41
Accuracy:  0.75
------
correct
Epoch:  42
Accuracy:  0.75
------
decrease weights
Epoch:  43
Accuracy:  0.5
------
correct
Epoch:  44
Accuracy:  0.5
------
increase weights
Epoch:  45
Accuracy:  0.5
------
increase weights
Epoch:  46
Accuracy:  0.5
------
decrease weights
Epoch:  47
Accuracy:  0.625
------
decrease weights
Epoch:  48
Accuracy:  0.25
------
increase weights
Epoch:  49
Accuracy:  0.75
------
correct
Epoch:  50
Accuracy:  0.75
------
decrease weights
Epoch:  51
Accuracy:  0.5
------
correct
Epoch:  52
Accuracy:  0.5
------
increase weights
Epoch:  53
Accuracy:  0.75
------
correct
Epoch:  54
Accuracy:  0.75
------
correct
Epoch:  55
Accuracy:  0.75
------
correct
Epoch:  56
Accuracy:  0.75
------
correct
Epoch:  57
Accuracy:  0.75
------
correct
Epoch:  58
Accuracy:  0.75
------
decrease weights
Epoch:  59
Accuracy:  0.5
------
correct
Epoch:  60
Accuracy:  0.5
------
increase weights
Epoch:  61
Accuracy:  0.5
------
increase weights
Epoch:  62
Accuracy:  0.5
------
decrease weights
Epoch:  63
Accuracy:  0.625
------
decrease weights
Epoch:  64
Accuracy:  0.25
------
increase weights
Epoch:  65
Accuracy:  0.75
------
correct
Epoch:  66
Accuracy:  0.75
------
decrease weights
Epoch:  67
Accuracy:  0.5
------
correct
Epoch:  68
Accuracy:  0.5
------
increase weights
Epoch:  69
Accuracy:  0.75
------
correct
Epoch:  70
Accuracy:  0.75
------
correct
Epoch:  71
Accuracy:  0.75
------
correct
Epoch:  72
Accuracy:  0.75
------
correct
Epoch:  73
Accuracy:  0.75
------
correct
Epoch:  74
Accuracy:  0.75
------
decrease weights
Epoch:  75
Accuracy:  0.5
------
correct
Epoch:  76
Accuracy:  0.5
------
increase weights
Epoch:  77
Accuracy:  0.5
------
increase weights
Epoch:  78
Accuracy:  0.5
------
decrease weights
Epoch:  79
Accuracy:  0.625
------
decrease weights
Epoch:  80
Accuracy:  0.25
------
increase weights
Epoch:  81
Accuracy:  0.75
------
correct
Epoch:  82
Accuracy:  0.75
------
decrease weights
Epoch:  83
Accuracy:  0.5
------
correct
Epoch:  84
Accuracy:  0.5
------
increase weights
Epoch:  85
Accuracy:  0.75
------
correct
Epoch:  86
Accuracy:  0.75
------
correct
Epoch:  87
Accuracy:  0.75
------
correct
Epoch:  88
Accuracy:  0.75
------
correct
Epoch:  89
Accuracy:  0.75
------
correct
Epoch:  90
Accuracy:  0.75
------
decrease weights
Epoch:  91
Accuracy:  0.5
------
correct
Epoch:  92
Accuracy:  0.5
------
increase weights
Epoch:  93
Accuracy:  0.5
------
increase weights
Epoch:  94
Accuracy:  0.5
------
decrease weights
Epoch:  95
Accuracy:  0.625
------
decrease weights
Epoch:  96
Accuracy:  0.25
------
increase weights
Epoch:  97
Accuracy:  0.75
------
correct
Epoch:  98
Accuracy:  0.75
------
decrease weights
Epoch:  99
Accuracy:  0.5
------
correct
Epoch:  100
Accuracy:  0.5
------
increase weights
Epoch:  101
Accuracy:  0.75
------
correct
Epoch:  102
Accuracy:  0.75
------
correct
Epoch:  103
Accuracy:  0.75
------
correct
Epoch:  104
Accuracy:  0.75
------
correct
Epoch:  105
Accuracy:  0.75
------
correct
Epoch:  106
Accuracy:  0.75
------
decrease weights
Epoch:  107
Accuracy:  0.5
------
correct
Epoch:  108
Accuracy:  0.5
------
increase weights
Epoch:  109
Accuracy:  0.5
------
increase weights
Epoch:  110
Accuracy:  0.5
------
decrease weights
Epoch:  111
Accuracy:  0.625
------
decrease weights
Epoch:  112
Accuracy:  0.25
------
increase weights
Epoch:  113
Accuracy:  0.75
------
correct
Epoch:  114
Accuracy:  0.75
------
decrease weights
Epoch:  115
Accuracy:  0.5
------
correct
Epoch:  116
Accuracy:  0.5
------
increase weights
Epoch:  117
Accuracy:  0.75
------
correct
Epoch:  118
Accuracy:  0.75
------
correct
Epoch:  119
Accuracy:  0.75
------
correct
Epoch:  120
Accuracy:  0.75
------
correct
Epoch:  121
Accuracy:  0.75
------
correct
Epoch:  122
Accuracy:  0.75
------
decrease weights
Epoch:  123
Accuracy:  0.5
------
correct
Epoch:  124
Accuracy:  0.5
------
increase weights
Epoch:  125
Accuracy:  0.5
------
increase weights
Epoch:  126
Accuracy:  0.5
------
decrease weights
Epoch:  127
Accuracy:  0.625
------
decrease weights
Epoch:  128
Accuracy:  0.25
------
increase weights
Epoch:  129
Accuracy:  0.75
------
correct
Epoch:  130
Accuracy:  0.75
------
decrease weights
Epoch:  131
Accuracy:  0.5
------
correct
Epoch:  132
Accuracy:  0.5
------
increase weights
Epoch:  133
Accuracy:  0.75
------
correct
Epoch:  134
Accuracy:  0.75
------
correct
Epoch:  135
Accuracy:  0.75
------
correct
Epoch:  136
Accuracy:  0.75
------
correct
Epoch:  137
Accuracy:  0.75
------
correct
Epoch:  138
Accuracy:  0.75
------
decrease weights
Epoch:  139
Accuracy:  0.5
------
correct
Epoch:  140
Accuracy:  0.5
------
increase weights
Epoch:  141
Accuracy:  0.5
------
increase weights
Epoch:  142
Accuracy:  0.5
------
decrease weights
Epoch:  143
Accuracy:  0.625
------
decrease weights
Epoch:  144
Accuracy:  0.25
------
increase weights
Epoch:  145
Accuracy:  0.75
------
correct
Epoch:  146
Accuracy:  0.75
------
decrease weights
Epoch:  147
Accuracy:  0.5
------
correct
Epoch:  148
Accuracy:  0.5
------
increase weights
Epoch:  149
Accuracy:  0.75
------
correct
Epoch:  150
Accuracy:  0.75
------
correct
Epoch:  151
Accuracy:  0.75
------
correct
Epoch:  152
Accuracy:  0.75
------
correct
Epoch:  153
Accuracy:  0.75
------
correct
Epoch:  154
Accuracy:  0.75
------
decrease weights
Epoch:  155
Accuracy:  0.5
------
correct
Epoch:  156
Accuracy:  0.5
------
increase weights
Epoch:  157
Accuracy:  0.5
------
increase weights
Epoch:  158
Accuracy:  0.5
------
decrease weights
Epoch:  159
Accuracy:  0.625
------
decrease weights
Epoch:  160
Accuracy:  0.25
------
increase weights
Epoch:  161
Accuracy:  0.75
------
correct
Epoch:  162
Accuracy:  0.75
------
decrease weights
Epoch:  163
Accuracy:  0.5
------
correct
Epoch:  164
Accuracy:  0.5
------
increase weights
Epoch:  165
Accuracy:  0.75
------
correct
Epoch:  166
Accuracy:  0.75
------
correct
Epoch:  167
Accuracy:  0.75
------
correct
Epoch:  168
Accuracy:  0.75
------
correct
Epoch:  169
Accuracy:  0.75
------
correct
Epoch:  170
Accuracy:  0.75
------
decrease weights
Epoch:  171
Accuracy:  0.5
------
correct
Epoch:  172
Accuracy:  0.5
------
increase weights
Epoch:  173
Accuracy:  0.5
------
increase weights
Epoch:  174
Accuracy:  0.5
------
decrease weights
Epoch:  175
Accuracy:  0.625
------
decrease weights
Epoch:  176
Accuracy:  0.25
------
increase weights
Epoch:  177
Accuracy:  0.75
------
correct
Epoch:  178
Accuracy:  0.75
------
decrease weights
Epoch:  179
Accuracy:  0.5
------
correct
Epoch:  180
Accuracy:  0.5
------
increase weights
Epoch:  181
Accuracy:  0.75
------
correct
Epoch:  182
Accuracy:  0.75
------
correct
Epoch:  183
Accuracy:  0.75
------
correct
Epoch:  184
Accuracy:  0.75
------
correct
Epoch:  185
Accuracy:  0.75
------
correct
Epoch:  186
Accuracy:  0.75
------
decrease weights
Epoch:  187
Accuracy:  0.5
------
correct
Epoch:  188
Accuracy:  0.5
------
increase weights
Epoch:  189
Accuracy:  0.5
------
increase weights
Epoch:  190
Accuracy:  0.5
------
decrease weights
Epoch:  191
Accuracy:  0.625
------
decrease weights
Epoch:  192
Accuracy:  0.25
------
increase weights
Epoch:  193
Accuracy:  0.75
------
correct
Epoch:  194
Accuracy:  0.75
------
decrease weights
Epoch:  195
Accuracy:  0.5
------
correct
Epoch:  196
Accuracy:  0.5
------
increase weights
Epoch:  197
Accuracy:  0.75
------
correct
Epoch:  198
Accuracy:  0.75
------
correct
Epoch:  199
Accuracy:  0.75
------
correct
Epoch:  200
Accuracy:  0.75

